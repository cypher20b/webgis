export interface register{
    id: number;
    username: string;
    password: string;
    fullname: string;
  }
  export interface login{
    // id: number;
    username: string;
    password: string;
  }